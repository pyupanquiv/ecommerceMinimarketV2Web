package edu.cibertec.ecommerce.service;

import edu.cibertec.ecommerce.model.DetallePedido;

public interface IDetallePedidoService {
	DetallePedido save (DetallePedido detallePedido);
}
