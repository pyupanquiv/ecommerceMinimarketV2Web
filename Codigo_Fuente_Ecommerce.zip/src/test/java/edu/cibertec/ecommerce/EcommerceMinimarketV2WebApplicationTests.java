package edu.cibertec.ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceMinimarketV2WebApplicationTests {
//	12122023
	@Test
	void contextLoads() {
	}

}
